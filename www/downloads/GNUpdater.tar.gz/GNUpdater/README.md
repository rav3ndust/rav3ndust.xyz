# linux-updater by rav3ndust
A quick and simple bash script to update and upgrade your distribution with one command. 
Please note that right now this script only works for Debian/Ubuntu based distros. 

To use it, follow these steps: 

-First make sure it is executable:

>$chmod +x updater.sh

-then, run the script: 

>$./updater.sh

...and that's it. The script will automatically update and upgrade your distro without further user interaction, aside from probably needing to input your password
for sudo. 

If you feel like contributing to make this project compatible with other Linux distributions, please feel free!
